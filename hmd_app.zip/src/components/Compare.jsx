import React, { useState } from 'react'
import { fetchRates } from '../services/api'
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'
const COLORS = ['#0088FE','#00C49F','#FFBB28','#FF8042','#9B5DE5','#F15BB5']
export default function Compare(){
  const [from, setFrom] = useState('Karachi')
  const [to, setTo] = useState('Lahore')
  const [weight, setWeight] = useState(1)
  const [cod, setCod] = useState(true)
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState([])
  const [error, setError] = useState(null)
  async function handleSearch(e){ e && e.preventDefault(); setLoading(true); setError(null)
    try{
      const res = await fetchRates({ from, to, weight, cod })
      setResults(res.results || [])
    } catch(err){
      setError(err.message || 'Failed to fetch')
    } finally{ setLoading(false) }
  }
  function renderPieFor(item){
    const data = [
      { name: 'Base', value: item.baseRate },
      { name: 'COD', value: item.codFee },
      { name: 'Insurance', value: item.insurance },
      { name: 'Fuel', value: item.fuelSurcharge || 0 }
    ].filter(d=>d.value>0)
    return (
      <div className="w-44 h-44">
        <ResponsiveContainer width="100%" height={160}>
          <PieChart>
            <Pie data={data} dataKey="value" outerRadius={50} innerRadius={18}>
              {data.map((_,i)=>(<Cell key={i} fill={COLORS[i%COLORS.length]} />))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
    )
  }
  return (
    <div>
      <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
        <input value={from} onChange={e=>setFrom(e.target.value)} className="border p-2 rounded bg-slate-800" placeholder="Origin (city)" />
        <input value={to} onChange={e=>setTo(e.target.value)} className="border p-2 rounded bg-slate-800" placeholder="Destination (city)" />
        <input type="number" step="0.1" value={weight} onChange={e=>setWeight(e.target.value)} className="border p-2 rounded bg-slate-800" />
        <div className="flex items-center space-x-3">
          <label className="flex items-center space-x-2"><input type="checkbox" checked={cod} onChange={e=>setCod(e.target.checked)} /> <span>Use COD</span></label>
          <button className="ml-auto bg-blue-600 text-white px-4 py-2 rounded" type="submit">Compare</button>
        </div>
      </form>
      {loading && <div className="p-4 text-center">Loading...</div>}
      {error && <div className="p-4 text-red-500">{error}</div>}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead className="text-left text-sm text-slate-400 border-b">
                <tr>
                  <th className="py-2 px-2">Courier</th>
                  <th className="py-2 px-2">Service</th>
                  <th className="py-2 px-2">ETA (days)</th>
                  <th className="py-2 px-2">Base</th>
                  <th className="py-2 px-2">COD</th>
                  <th className="py-2 px-2">Insurance</th>
                  <th className="py-2 px-2">Fuel</th>
                  <th className="py-2 px-2">Total</th>
                  <th className="py-2 px-2">Rating</th>
                </tr>
              </thead>
              <tbody>
                {results.length===0 && !loading && <tr><td colSpan={9} className="p-6 text-center text-slate-400">No results. Click Compare.</td></tr>}
                {results.map((r,i)=> (
                  <tr key={i} className="border-b hover:bg-slate-800/40">
                    <td className="py-2 px-2 font-semibold">{r.courier}</td>
                    <td className="py-2 px-2">{r.service}</td>
                    <td className="py-2 px-2">{r.etaDays}</td>
                    <td className="py-2 px-2">{r.baseRate}</td>
                    <td className="py-2 px-2">{r.codFee}</td>
                    <td className="py-2 px-2">{r.insurance}</td>
                    <td className="py-2 px-2">{r.fuelSurcharge||0}</td>
                    <td className="py-2 px-2 font-bold">{r.total}</td>
                    <td className="py-2 px-2">{r.rating || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div>
          <div className="bg-slate-900/60 p-4 rounded mb-4">
            <h3 className="font-semibold mb-2">Quick Tips</h3>
            <ul className="text-sm text-slate-400 list-disc pl-5">
              <li>Include packaging weight.</li>
              <li>Compare COD fees — they vary significantly.</li>
              <li>Insurance recommended for high-value items.</li>
            </ul>
          </div>
          <div className="bg-black/40 p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Visual</h3>
            {results[0] ? renderPieFor(results[0]) : <div className="text-sm text-slate-400">Run a search to see cost breakdown.</div>}
          </div>
        </div>
      </div>
    </div>
  )
}
