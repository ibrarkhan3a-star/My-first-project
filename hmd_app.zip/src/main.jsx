import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'
import { register as registerSW } from './registerServiceWorker'
createRoot(document.getElementById('root')).render(<App />)
registerSW();
