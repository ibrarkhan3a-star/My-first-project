/* HmD PWA service worker: cache app shell and API responses */
const CACHE_NAME = 'hmd-shell-v1';
const DATA_CACHE = 'hmd-data-v1';
const APP_SHELL_FILES = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/android-chrome-192x192.png',
  '/icons/android-chrome-512x512.png'
];

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL_FILES))
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(key => {
        if (key !== CACHE_NAME && key !== DATA_CACHE) return caches.delete(key);
      }))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);

  if (url.pathname.startsWith('/api/rates')) {
    event.respondWith((async () => {
      try {
        const networkResponse = await fetch(req);
        const clone = networkResponse.clone();
        const cache = await caches.open(DATA_CACHE);
        cache.put(req, clone);
        return networkResponse;
      } catch (err) {
        const cache = await caches.open(DATA_CACHE);
        const cached = await cache.match(req);
        if (cached) return cached;
        return new Response(JSON.stringify({ error: 'offline', results: [] }), { headers: { 'Content-Type': 'application/json' }});
      }
    })());
    return;
  }

  event.respondWith(
    caches.match(req).then(cached => {
      if (cached) return cached;
      return fetch(req).catch(() => {
        if (req.mode === 'navigate') return caches.match('/index.html');
      });
    })
  );
});
