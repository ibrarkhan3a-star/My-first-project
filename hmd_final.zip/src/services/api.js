import axios from 'axios'
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:4000'
export async function fetchRates({ from, to, weight, cod }){
  const res = await axios.get(`${API_URL}/api/rates`, { params: { from, to, weight, cod } })
  return res.data
}
