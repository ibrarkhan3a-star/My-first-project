import React from 'react'
import Compare from './components/Compare'
export default function App(){
  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto bg-black/60 p-6 rounded-2xl shadow">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Help Me Decide — HmD</h1>
            <p className="text-sm text-slate-400">Compare courier rates, COD, insurance and delivery times instantly. (Pakistan)</p>
          </div>
          <div className="text-sm text-slate-400">Alpha</div>
        </header>
        <Compare />
        <footer className="mt-6 text-xs text-slate-500">Prototype UI — connect to your HmD backend at REACT_APP_API_URL</footer>
      </div>
    </div>
  )
}
