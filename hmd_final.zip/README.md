HmD Frontend (PWA) - Dark theme (Pakistan)
------------------------------------------
This folder contains a ready React frontend (Create-React-App style) prepared as a PWA (English only).
It calls your backend at /api/rates to fetch real courier data (domestic Pakistan).

Steps to run locally:
  1. Install Node.js (v18+)
  2. npm install
  3. Set environment variable if needed:
     REACT_APP_API_URL=http://localhost:4000
  4. npm start

To build for production:
  npm run build
  Serve the build folder (or deploy to Vercel/Netlify)

After deployment, use PWABuilder to convert to APK.
